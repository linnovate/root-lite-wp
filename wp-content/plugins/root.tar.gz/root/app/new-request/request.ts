export class Request {
    constructor(
       public name: string,
       public title: string,
       public description: string,
       public icon: string
    ) { }

}